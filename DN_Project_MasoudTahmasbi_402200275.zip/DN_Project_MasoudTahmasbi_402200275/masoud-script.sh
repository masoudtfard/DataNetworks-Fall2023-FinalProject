#!/bin/bash

# Check if exactly two arguments are provided
if [ "$#" -ne 2 ]; then
    echo "Usage: $0 <node1> <node2>"
    exit 1
fi

node1="$1"
node2="$2"

# Get the IP addresses of the nodes
ip_node1=$(sudo ip netns exec "$node1" ip addr show "eth-$node1" | grep -oP 'inet \K[\d.]+')

sudo ip netns exec "$node2" ping -c 4 "$ip_node1"

